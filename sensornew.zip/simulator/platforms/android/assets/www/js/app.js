angular.module('app', ['ionic', 'app.controllers'])

.run(function($ionicPlatform, $pouchDB) {
    $ionicPlatform.ready(function() {
        if(window.cordova && window.cordova.plugins.Keyboard) {
            cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
        }
        if(window.StatusBar) {
            StatusBar.styleDefault();
        }
    });
    $pouchDB.setDatabase("sensorsdetails");
    if(ionic.Platform.isAndroid()) {
        $pouchDB.sync("http://52.67.20.14:5984/sensorsdetails");
    } else {
        $pouchDB.sync("http://52.67.20.14:5984/sensorsdetails");
    }
})

.config(function($stateProvider, $urlRouterProvider) {
    $stateProvider
.state("login", {
            "url": "/login",
            "templateUrl": "templates/login.html",
            "controller": "AppCtrl"
        })
        .state("list", {
            "url": "/list",
            "templateUrl": "templates/list.html",
            "controller": "MainController"
        })
        .state("item", {
            "url": "/item/:documentId/:documentRevision",
            "templateUrl": "templates/item.html",
            "controller": "MainController"
        });
    $urlRouterProvider.otherwise("login");
})

.controller("MainController", function($scope, $rootScope, $state, $stateParams, $ionicHistory, $pouchDB) {

    $scope.items = {};
$scope.itemTimestamp=new Date();

//$scope.itemTimestamp=$scope.itemTimestamp.toLocaleDateString()+" "+$scope.itemTimestamp.toLocaleTimeString();

//$scope.itemTimestamp=$scope.itemTimestamp.toLocaleDateString();
//$scope.itemTimestamp= (date.toString().split('')[0]);
    $pouchDB.startListening();

    $rootScope.$on("$pouchDB:change", function(event, data) {
        $scope.items[data.doc._id] = data.doc;
        $scope.$apply();
    });

    $rootScope.$on("$pouchDB:delete", function(event, data) {
        delete $scope.items[data.doc._id];
        $scope.$apply();
    });

    if($stateParams.documentId) {
        $pouchDB.get($stateParams.documentId).then(function(result) {
            $scope.inputForm = result;
if($scope.inputForm.date === undefined){
$scope.inputForm.date=$scope.itemTimestamp;
}

        });
    }



    $scope.save = function(deviceid,sensorname,Description,sensorType, value, sensorReading,date) {
        var jsonDocument = {
            "deviceid": deviceid,
            "sensorname": sensorname,
             "Description": Description,
               "sensorType": sensorType,
                 "value": value,  
                      "sensorReading": sensorReading,
                        "date": $scope.itemTimestamp
        };
        if($stateParams.documentId) {
            jsonDocument["_id"] = $stateParams.documentId;
            jsonDocument["_rev"] = $stateParams.documentRevision;
        }
        $pouchDB.save(jsonDocument).then(function(response) {
            $state.go("list");
        }, function(error) {
            console.log("ERROR -> " + error);
        });
    }


$scope.Ctrl=function(id, rev)
{
    $scope.date = new Date(id, rev);




}






    $scope.delete = function(id, rev) {
        $pouchDB.delete(id, rev);
    }

    $scope.back = function() {
        $ionicHistory.goBack();
    }    

})

.service("$pouchDB", ["$rootScope", "$q", function($rootScope, $q) {

    var database;
    var changeListener;

    this.setDatabase = function(databaseName) {
        database = new PouchDB(databaseName);
    }

    this.startListening = function() {
        changeListener = database.changes({
            live: true,
            include_docs: true
        }).on("change", function(change) {
            if(!change.deleted) {
                $rootScope.$broadcast("$pouchDB:change", change);
            } else {
                $rootScope.$broadcast("$pouchDB:delete", change);
            }
        });
    }

    this.stopListening = function() {
        changeListener.cancel();
    }

    this.sync = function(remoteDatabase) {
        database.sync(remoteDatabase, {live: true, retry: true});
    }

    this.save = function(jsonDocument) {
        var deferred = $q.defer();
        if(!jsonDocument._id) {
            database.post(jsonDocument).then(function(response) {
                deferred.resolve(response);
            }).catch(function(error) {
                deferred.reject(error);
            });
        } else {
            database.put(jsonDocument).then(function(response) {
                deferred.resolve(response);
            }).catch(function(error) {
                deferred.reject(error);
            });
        }
        return deferred.promise;
    }

    this.delete = function(documentId, documentRevision) {
        return database.remove(documentId, documentRevision);
    }

    this.get = function(documentId) {
        return database.get(documentId);
    }

    this.destroy = function() {
        database.destroy();
    }

}]);
